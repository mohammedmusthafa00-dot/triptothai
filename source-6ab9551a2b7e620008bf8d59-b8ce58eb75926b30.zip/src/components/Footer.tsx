import { Link } from '@tanstack/react-router'

export function Footer() {
  return (
    <footer>
      <div className="container">
        <div className="footer-grid">
          <div className="footer-col">
            <h4>Trip To Thai</h4>
            <p>
              Thailand holidays, made easy — from Tamil Nadu to Thailand.
              Flights, hotels, food, tours and transfers, planned end to end.
            </p>
          </div>
          <div className="footer-col">
            <h4>Explore</h4>
            <Link to="/">Home</Link>
            <Link to="/tours">Tour packages</Link>
            <Link to="/about">About us</Link>
            <Link to="/contact">Contact</Link>
          </div>
          <div className="footer-col">
            <h4>Get in touch</h4>
            <a href="https://wa.me/91XXXXXXXXXX">WhatsApp: +91 XXXXX XXXXX</a>
            <a href="mailto:hello@triptothai.com">hello@triptothai.com</a>
          </div>
        </div>
        <div className="footer-bottom">
          &copy; {new Date().getFullYear()} Trip To Thai. All rights reserved.
        </div>
      </div>
    </footer>
  )
}
