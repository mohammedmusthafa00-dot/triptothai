import { Link } from '@tanstack/react-router'

export function Header() {
  return (
    <header>
      <div className="nav-wrap">
        <Link to="/" className="logo-link">
          <img
            src="/.netlify/images?url=/logo.png&w=104&h=104&fit=cover&fm=webp"
            width={52}
            height={52}
            alt="Trip To Thai logo"
          />
          <span>
            Trip To <em>Thai</em>
          </span>
        </Link>
        <nav>
          <ul>
            <li>
              <Link to="/">Home</Link>
            </li>
            <li>
              <Link to="/tours">Tours</Link>
            </li>
            <li>
              <Link to="/about">About</Link>
            </li>
            <li>
              <Link to="/contact">Contact</Link>
            </li>
          </ul>
        </nav>
        <a href="https://wa.me/91XXXXXXXXXX" className="wa-btn">
          WhatsApp Us
        </a>
      </div>
    </header>
  )
}
