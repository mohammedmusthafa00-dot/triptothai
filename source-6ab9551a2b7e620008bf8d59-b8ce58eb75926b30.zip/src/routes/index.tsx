import { Link, createFileRoute } from '@tanstack/react-router'
import packages from '@/data/packages'
import {
  FlightIcon,
  FoodIcon,
  HotelIcon,
  TourIcon,
  TransferIcon,
} from '@/components/icons'

export const Route = createFileRoute('/')({
  component: Home,
})

const destinationBlurbs: Record<string, string> = {
  Bangkok:
    "Temples, markets, rooftop bars and river cruises in Thailand's buzzing capital.",
  Pattaya:
    'Beaches, water sports and family-friendly attractions just hours from Bangkok.',
  Phuket:
    "Island hopping, snorkeling and sunset views on Thailand's largest island.",
  'Chiang Mai':
    'Mountain temples, elephant sanctuaries and the famous night markets.',
  'Islands & beaches':
    'Krabi, Koh Samui and Phi Phi — turquoise water and long-tail boat rides.',
}

const destinations = [
  ...packages.map((pkg) => ({
    name: pkg.destination,
    blurb: destinationBlurbs[pkg.destination] ?? pkg.blurb,
    gradient: pkg.gradient,
    to: '/tours' as const,
    cta: 'See packages',
  })),
  {
    name: 'Custom itinerary',
    blurb:
      "Tell us your dates and budget — we'll design a trip around what you want.",
    gradient: 'linear-gradient(135deg,#8C6A16,#0B1F3D)',
    to: '/contact' as const,
    cta: 'Enquire now',
  },
]

function Home() {
  return (
    <>
      <section className="hero">
        <div className="hero-inner">
          <span className="eyebrow">FROM TAMIL NADU TO THAILAND</span>
          <h1>
            Thailand holidays, <em>made easy</em>
          </h1>
          <p>
            Flights, hotels, food, tours and transfers — planned end to end,
            so all you have to do is pack your bags.
          </p>
          <div className="btn-row">
            <Link to="/contact" className="btn btn-primary">
              Get a free quote
            </Link>
            <Link to="/tours" className="btn btn-ghost">
              View tour packages
            </Link>
          </div>
        </div>
      </section>

      <section className="services">
        <div className="container services-grid">
          <div className="service-item">
            <div className="icon">
              <FlightIcon />
            </div>
            <span>Flights</span>
          </div>
          <div className="service-item">
            <div className="icon">
              <HotelIcon />
            </div>
            <span>Hotels</span>
          </div>
          <div className="service-item">
            <div className="icon">
              <FoodIcon />
            </div>
            <span>Food</span>
          </div>
          <div className="service-item">
            <div className="icon">
              <TourIcon />
            </div>
            <span>Tours</span>
          </div>
          <div className="service-item">
            <div className="icon">
              <TransferIcon />
            </div>
            <span>Transfers</span>
          </div>
        </div>
      </section>

      <section className="block">
        <div className="container">
          <div className="section-head">
            <span className="eyebrow">POPULAR DESTINATIONS</span>
            <h2>Where would you like to go?</h2>
            <p>
              Hand-picked itineraries across Thailand's most loved cities and
              islands.
            </p>
          </div>
          <div className="dest-grid">
            {destinations.map((dest) => (
              <div className="dest-card" key={dest.name}>
                <div className="dest-photo" style={{ background: dest.gradient }}>
                  {dest.name}
                </div>
                <div className="dest-body">
                  <h3>{dest.name}</h3>
                  <p>{dest.blurb}</p>
                  <Link to={dest.to}>{dest.cta}</Link>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section
        className="block"
        style={{
          background: '#fff',
          borderTop: '1px solid #EEE7D8',
          borderBottom: '1px solid #EEE7D8',
        }}
      >
        <div className="container">
          <div className="section-head">
            <span className="eyebrow">WHY TRIP TO THAI</span>
            <h2>Planned by people who know Thailand</h2>
          </div>
          <div className="why-grid">
            <div className="why-item">
              <div className="num">01</div>
              <h3>Departures from Tamil Nadu</h3>
              <p>
                Flight and visa guidance built specifically for travelers
                flying out of Chennai and nearby cities.
              </p>
            </div>
            <div className="why-item">
              <div className="num">02</div>
              <h3>Everything in one booking</h3>
              <p>
                Flights, hotels, meals, tours and airport transfers arranged
                together — no juggling multiple vendors.
              </p>
            </div>
            <div className="why-item">
              <div className="num">03</div>
              <h3>Real support on the ground</h3>
              <p>
                A WhatsApp line to us throughout your trip, so help is always
                one message away.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className="cta-band">
        <div className="container">
          <h2>Ready to plan your Thailand trip?</h2>
          <p>
            Send us your travel dates and we'll reply with a custom itinerary
            and price within 24 hours.
          </p>
          <Link to="/contact" className="btn btn-primary">
            Get a free quote
          </Link>
        </div>
      </section>
    </>
  )
}
