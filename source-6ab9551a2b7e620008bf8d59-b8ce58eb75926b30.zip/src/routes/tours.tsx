import { Link, createFileRoute } from '@tanstack/react-router'
import packages from '@/data/packages'

export const Route = createFileRoute('/tours')({
  component: Tours,
  head: () => ({
    meta: [
      { title: 'Tour Packages | Trip To Thai' },
      {
        name: 'description',
        content:
          'Thailand tour packages for Bangkok, Pattaya, Phuket, Chiang Mai and the islands, planned from Tamil Nadu by Trip To Thai.',
      },
    ],
  }),
})

function Tours() {
  return (
    <>
      <section className="hero" style={{ padding: '70px 0' }}>
        <div className="hero-inner">
          <span className="eyebrow">TOUR PACKAGES</span>
          <h1 style={{ fontSize: 38 }}>
            Pick a package, or ask us to <em>customize</em> one
          </h1>
          <p>
            Every package includes flights, hotel, breakfast, listed
            sightseeing and airport transfers. Prices are per person on
            twin-sharing — message us for exact dates and updated pricing.
          </p>
        </div>
      </section>

      <section className="block">
        <div className="container">
          {packages.map((pkg) => (
            <div className="package" key={pkg.id}>
              <div className="tag" style={{ background: pkg.gradient }}>
                {pkg.destination}
              </div>
              <div>
                <h3>
                  {pkg.title} — {pkg.duration}
                </h3>
                <ul>
                  {pkg.includes.map((item) => (
                    <li key={item}>{item}</li>
                  ))}
                </ul>
              </div>
              <div className="price">
                <span>Starting from</span>
                <div className="amt">{pkg.price}</div>
                <Link
                  to="/contact"
                  className="btn btn-primary"
                  style={{
                    display: 'inline-block',
                    marginTop: 12,
                    padding: '9px 18px',
                    fontSize: 13,
                  }}
                >
                  Enquire
                </Link>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section className="cta-band">
        <div className="container">
          <h2>Don't see the trip you want?</h2>
          <p>
            Tell us your dates, budget and group size — we'll build a custom
            itinerary just for you.
          </p>
          <Link to="/contact" className="btn btn-primary">
            Request a custom quote
          </Link>
        </div>
      </section>
    </>
  )
}
