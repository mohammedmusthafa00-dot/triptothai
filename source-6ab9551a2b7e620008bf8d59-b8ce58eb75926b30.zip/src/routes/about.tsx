import { Link, createFileRoute } from '@tanstack/react-router'

export const Route = createFileRoute('/about')({
  component: About,
  head: () => ({
    meta: [
      { title: 'About Us | Trip To Thai' },
      {
        name: 'description',
        content:
          'Trip To Thai helps travelers from Tamil Nadu plan complete, worry-free holidays to Thailand.',
      },
    ],
  }),
})

function About() {
  return (
    <>
      <section className="hero" style={{ padding: '70px 0' }}>
        <div className="hero-inner">
          <span className="eyebrow">ABOUT US</span>
          <h1 style={{ fontSize: 38 }}>
            Thailand holidays, planned with local care
          </h1>
          <p>
            We're a Tamil Nadu based travel team who plan every Thailand trip
            the way we'd plan our own.
          </p>
        </div>
      </section>

      <section className="block">
        <div className="container" style={{ maxWidth: 760 }}>
          <h2 style={{ marginBottom: 16 }}>Our story</h2>
          <p style={{ color: 'var(--muted)', marginBottom: 18 }}>
            Trip To Thai started with a simple frustration: travelers from
            Tamil Nadu heading to Thailand had to piece together flights,
            hotels, tours and transfers from five different websites, in
            three different currencies, and hope it all lined up. We built
            Trip To Thai to make that one conversation instead — tell us your
            dates and what you want to see, and we handle the rest.
          </p>
          <p style={{ color: 'var(--muted)', marginBottom: 18 }}>
            From Bangkok's temples to Phuket's islands and Chiang Mai's
            mountains, every itinerary we plan is built around real feedback
            from travelers who've made the trip before — not just a template
            pulled off a brochure.
          </p>
        </div>
      </section>

      <section
        className="block"
        style={{
          background: '#fff',
          borderTop: '1px solid #EEE7D8',
          borderBottom: '1px solid #EEE7D8',
        }}
      >
        <div className="container">
          <div className="section-head">
            <span className="eyebrow">WHAT WE DO</span>
            <h2>Five things, handled end to end</h2>
          </div>
          <div className="why-grid">
            <div className="why-item">
              <h3>Flights</h3>
              <p>
                Best-value return flights from Chennai and nearby cities,
                timed around your itinerary.
              </p>
            </div>
            <div className="why-item">
              <h3>Hotels</h3>
              <p>
                Hand-checked hotels in the right neighborhoods, not just the
                cheapest listing.
              </p>
            </div>
            <div className="why-item">
              <h3>Food</h3>
              <p>
                Breakfasts included, plus recommendations for vegetarian and
                South Indian-friendly meals in Thailand.
              </p>
            </div>
            <div className="why-item">
              <h3>Tours</h3>
              <p>
                Temple visits, island cruises, night markets and cultural
                experiences, booked and confirmed in advance.
              </p>
            </div>
            <div className="why-item">
              <h3>Transfers</h3>
              <p>
                Airport pickups, drops and inter-city transport arranged so
                you're never stuck figuring out a taxi.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className="cta-band">
        <div className="container">
          <h2>Let's plan your Thailand trip together</h2>
          <p>
            Message us on WhatsApp or fill out our contact form — we usually
            reply within a few hours.
          </p>
          <Link to="/contact" className="btn btn-primary">
            Contact us
          </Link>
        </div>
      </section>
    </>
  )
}
