import { useState } from 'react'
import { createFileRoute } from '@tanstack/react-router'
import { MailIcon, PinIcon, WhatsAppIcon } from '@/components/icons'

export const Route = createFileRoute('/contact')({
  component: Contact,
  head: () => ({
    meta: [
      { title: 'Contact Us | Trip To Thai' },
      {
        name: 'description',
        content:
          'Get a free Thailand holiday quote from Trip To Thai. Message us on WhatsApp or send an enquiry.',
      },
    ],
  }),
})

const destinationOptions = [
  'Bangkok',
  'Pattaya',
  'Phuket',
  'Chiang Mai',
  'Islands (Krabi / Koh Samui)',
  'Custom / not sure yet',
]

function encode(data: Record<string, string>) {
  return Object.entries(data)
    .map(([key, val]) => `${encodeURIComponent(key)}=${encodeURIComponent(val)}`)
    .join('&')
}

const initialFields = {
  name: '',
  phone: '',
  email: '',
  destination: destinationOptions[0],
  dates: '',
  travellers: '',
  message: '',
  'bot-field': '',
}

function Contact() {
  const [fields, setFields] = useState(initialFields)
  const [status, setStatus] = useState<'idle' | 'submitting' | 'done'>('idle')

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>,
  ) => {
    setFields((prev) => ({ ...prev, [e.target.name]: e.target.value }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setStatus('submitting')
    await fetch('/__forms.html', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: encode({ 'form-name': 'contact', ...fields }),
    })
    setStatus('done')
  }

  return (
    <>
      <section className="hero" style={{ padding: '70px 0' }}>
        <div className="hero-inner">
          <span className="eyebrow">CONTACT US</span>
          <h1 style={{ fontSize: 38 }}>
            Get a free <em>quote</em>
          </h1>
          <p>
            Tell us your travel dates, destination and group size — we'll
            send a custom itinerary and price within 24 hours.
          </p>
        </div>
      </section>

      <section className="block">
        <div className="container contact-wrap">
          <div className="form-card">
            {status === 'done' ? (
              <div className="success-message">
                <h3>Thanks — enquiry sent!</h3>
                <p>We'll reply within 24 hours with a custom itinerary and price.</p>
              </div>
            ) : (
              <form name="contact" onSubmit={handleSubmit}>
                <input type="hidden" name="form-name" value="contact" />
                <p style={{ display: 'none' }}>
                  <label>
                    Don't fill this out:{' '}
                    <input
                      name="bot-field"
                      value={fields['bot-field']}
                      onChange={handleChange}
                    />
                  </label>
                </p>

                <label htmlFor="name">Full name</label>
                <input
                  type="text"
                  id="name"
                  name="name"
                  required
                  placeholder="Your name"
                  value={fields.name}
                  onChange={handleChange}
                />

                <label htmlFor="phone">Phone / WhatsApp number</label>
                <input
                  type="tel"
                  id="phone"
                  name="phone"
                  required
                  placeholder="+91 XXXXX XXXXX"
                  value={fields.phone}
                  onChange={handleChange}
                />

                <label htmlFor="email">Email</label>
                <input
                  type="email"
                  id="email"
                  name="email"
                  required
                  placeholder="you@example.com"
                  value={fields.email}
                  onChange={handleChange}
                />

                <label htmlFor="destination">Destination</label>
                <select
                  id="destination"
                  name="destination"
                  value={fields.destination}
                  onChange={handleChange}
                >
                  {destinationOptions.map((option) => (
                    <option key={option}>{option}</option>
                  ))}
                </select>

                <label htmlFor="dates">Travel dates</label>
                <input
                  type="text"
                  id="dates"
                  name="dates"
                  placeholder="e.g. 12-16 December, or flexible"
                  value={fields.dates}
                  onChange={handleChange}
                />

                <label htmlFor="travellers">Number of travellers</label>
                <input
                  type="number"
                  id="travellers"
                  name="travellers"
                  min={1}
                  placeholder="e.g. 4"
                  value={fields.travellers}
                  onChange={handleChange}
                />

                <label htmlFor="message">Anything else we should know?</label>
                <textarea
                  id="message"
                  name="message"
                  placeholder="Budget, special occasions, food preferences, etc."
                  value={fields.message}
                  onChange={handleChange}
                />

                <button
                  type="submit"
                  className="btn btn-primary"
                  style={{ width: '100%', border: 'none', cursor: 'pointer' }}
                  disabled={status === 'submitting'}
                >
                  {status === 'submitting' ? 'Sending…' : 'Send enquiry'}
                </button>
              </form>
            )}
          </div>

          <div className="contact-info">
            <h3>Prefer to talk directly?</h3>
            <p>We usually reply fastest on WhatsApp.</p>

            <div className="info-line">
              <div className="ic">
                <WhatsAppIcon />
              </div>
              <div>
                <strong>WhatsApp</strong>
                <br />
                <a href="https://wa.me/91XXXXXXXXXX">+91 XXXXX XXXXX</a>
              </div>
            </div>

            <div className="info-line">
              <div className="ic">
                <MailIcon />
              </div>
              <div>
                <strong>Email</strong>
                <br />
                <a href="mailto:hello@triptothai.com">hello@triptothai.com</a>
              </div>
            </div>

            <div className="info-line">
              <div className="ic">
                <PinIcon />
              </div>
              <div>
                <strong>Based in</strong>
                <br />
                Tamil Nadu, India
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  )
}
