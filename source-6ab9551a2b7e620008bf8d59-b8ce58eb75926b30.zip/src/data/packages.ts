export interface TourPackage {
  id: string
  destination: string
  title: string
  duration: string
  blurb: string
  includes: Array<string>
  price: string
  gradient: string
}

const packages: Array<TourPackage> = [
  {
    id: 'bangkok',
    destination: 'Bangkok',
    title: 'Bangkok City Explorer',
    duration: '4 Days / 3 Nights',
    blurb:
      "Temples, markets, rooftop bars and river cruises in Thailand's buzzing capital.",
    includes: [
      'Return flights from Chennai',
      '3-star hotel, breakfast included',
      'Grand Palace & Wat Arun city tour',
      'Chao Phraya river dinner cruise',
      'Airport pickup and drop',
    ],
    price: '₹29,999',
    gradient: 'linear-gradient(135deg,#0B1F3D,#3A5C8C)',
  },
  {
    id: 'pattaya',
    destination: 'Pattaya',
    title: 'Bangkok + Pattaya Combo',
    duration: '5 Days / 4 Nights',
    blurb:
      'Beaches, water sports and family-friendly attractions just hours from Bangkok.',
    includes: [
      'Return flights from Chennai',
      'Hotels in both Bangkok and Pattaya',
      'Coral Island speedboat trip',
      'Alcazar cabaret show tickets',
      'All transfers by private vehicle',
    ],
    price: '₹39,999',
    gradient: 'linear-gradient(135deg,#5FA69A,#1E3A63)',
  },
  {
    id: 'phuket',
    destination: 'Phuket',
    title: 'Phuket Island Getaway',
    duration: '4 Days / 3 Nights',
    blurb:
      "Island hopping, snorkeling and sunset views on Thailand's largest island.",
    includes: [
      'Return flights from Chennai',
      'Beachfront hotel, breakfast included',
      'Phi Phi island day cruise with lunch',
      'Old Phuket Town walking tour',
      'Airport pickup and drop',
    ],
    price: '₹39,999',
    gradient: 'linear-gradient(135deg,#C9971C,#8C6A16)',
  },
  {
    id: 'chiang-mai',
    destination: 'Chiang Mai',
    title: 'Chiang Mai Culture & Nature',
    duration: '4 Days / 3 Nights',
    blurb:
      'Mountain temples, elephant sanctuaries and the famous night markets.',
    includes: [
      'Return flights via Bangkok',
      'Boutique hotel, breakfast included',
      'Ethical elephant sanctuary visit',
      'Doi Suthep temple & night market tour',
      'All transfers included',
    ],
    price: '₹36,999',
    gradient: 'linear-gradient(135deg,#16294D,#5FA69A)',
  },
  {
    id: 'islands',
    destination: 'Islands & beaches',
    title: 'Krabi & Koh Samui Island Hopper',
    duration: '6 Days / 5 Nights',
    blurb:
      'Krabi, Koh Samui and Phi Phi — turquoise water and long-tail boat rides.',
    includes: [
      'Return flights from Chennai',
      'Two island stays, breakfast included',
      'Four Islands speedboat tour',
      'Railay Beach viewpoint hike',
      'Ferry and airport transfers',
    ],
    price: '₹59,999',
    gradient: 'linear-gradient(135deg,#3A5C8C,#C9971C)',
  },
]

export default packages
