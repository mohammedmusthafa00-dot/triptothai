# Trip To Thai

A marketing site for Trip To Thai, a Tamil Nadu based travel agency that plans complete Thailand holidays — flights, hotels, food, tours and airport transfers — for Bangkok, Pattaya, Phuket, Chiang Mai and the southern islands.

## Pages

- **Home** — hero, service overview, popular-destination cards, and why-book-with-us section.
- **Tours** — five sample packages (Bangkok, Pattaya, Phuket, Chiang Mai, Islands) with inclusions and starting prices.
- **About** — the agency's story and the five services it handles end to end.
- **Contact** — an enquiry form (name, phone, email, destination, dates, group size) plus WhatsApp and email details.

## Tech

- [TanStack Start](https://tanstack.com/start) (React 19 + TanStack Router) on Vite
- Tailwind CSS 4 for resets, with a hand-written navy/gold design system in `src/styles.css`
- [Netlify Forms](https://docs.netlify.com/forms/setup/) for the contact form, submitted via AJAX
- Deployed on Netlify

## Run locally

```bash
npm install
npm run dev
```

The dev server runs on port 3000 (or via `netlify dev` for full Netlify feature emulation, including forms on a deployed preview).

## Notes

The WhatsApp number and email address in the header, footer and contact page are placeholders (`+91 XXXXXXXXXX`, `hello@triptothai.com`) — swap in the real contact details before going live.
