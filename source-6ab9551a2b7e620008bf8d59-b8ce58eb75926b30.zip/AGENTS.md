# AGENTS.md

This document orients AI agents and developers working on this codebase.

## Project Overview

Trip To Thai is a marketing site for a Tamil Nadu based travel agency that plans complete Thailand holidays — flights, hotels, food, tours and transfers — for Bangkok, Pattaya, Phuket, Chiang Mai and the southern islands. Built with TanStack Start and deployed on Netlify.

### Tech Stack

| Layer | Technology |
|-------|------------|
| Framework | TanStack Start |
| Frontend | React 19, TanStack Router v1 |
| Build | Vite 7 |
| Styling | Tailwind CSS 4 (utility reset) + hand-written CSS design system in `src/styles.css` |
| Forms | Netlify Forms (AJAX submission with a static detection skeleton) |
| Language | TypeScript 5.9 (strict mode) |
| Deployment | Netlify |

## Directory Structure

```
├── public
│   ├── favicon.ico
│   ├── logo.png            # Brand logo (navy/gold circular emblem)
│   └── __forms.html         # Hidden static form skeleton so Netlify detects the contact form at build time
├── src
│   ├── components
│   │   ├── Header.tsx        # Sticky navy nav bar: logo, page links, WhatsApp CTA
│   │   ├── Footer.tsx         # Site footer: brand blurb, sitemap, contact links
│   │   └── icons.tsx          # Small inline SVG icon set (flights, hotels, food, tours, transfers, contact icons)
│   ├── data
│   │   └── packages.ts        # Sample tour package data (Bangkok, Pattaya, Phuket, Chiang Mai, Islands) — shared by the home and tours pages
│   ├── routes
│   │   ├── __root.tsx          # Document shell + shared Header/Footer layout
│   │   ├── index.tsx            # Home page
│   │   ├── tours.tsx             # Tour packages page
│   │   ├── about.tsx              # About page
│   │   └── contact.tsx             # Contact page with the enquiry form
│   ├── router.tsx               # TanStack Router setup
│   └── styles.css                 # Tailwind import + the navy/gold design system (CSS custom properties, component classes)
├── netlify.toml                # Build command, publish directory, dev server settings
├── package.json
└── tsconfig.json                # `@/*` path alias for `src/*`
```

## Key Concepts

### Routing

File-based routing via TanStack Router. Every route file exports a `Route` created with `createFileRoute`. `__root.tsx` wraps every page with the `Header` and `Footer` components around an `<Outlet />`.

### Design system

The brand palette (navy `#0B1F3D`, gold `#C9971C`, cream background, teal accent) lives as CSS custom properties at the top of `src/styles.css`, alongside the component classes (`.hero`, `.dest-card`, `.package`, `.form-card`, etc.) used across pages. Tailwind is imported for utility resets but the page layouts intentionally use these named classes rather than long Tailwind utility chains, to match the source design.

### Tour packages

`src/data/packages.ts` is the single source of truth for the five sample packages. The home page's destination cards and the tours page's package list both read from it — update pricing, inclusions or copy in one place.

### Contact form (Netlify Forms)

The contact form submits via `fetch` to `/__forms.html` (not `/`), because TanStack Start's SSR catch-all would otherwise intercept a POST to `/` before Netlify's form-processing middleware sees it. `public/__forms.html` is a hidden, unstyled duplicate of the form's fields that exists purely so Netlify's build bot registers the `contact` form at deploy time. If you add or rename a field in `src/routes/contact.tsx`, mirror the change in `public/__forms.html` or submissions will be rejected.

## Conventions

- Components: PascalCase. Routes: kebab-case/lowercase files matching TanStack Router conventions.
- Import paths use the `@/` alias for anything under `src/`.
- Prefer the existing CSS component classes over ad hoc Tailwind utility soup when extending a page — it keeps the navy/gold visual language consistent.

## Known placeholders

The WhatsApp number (`+91 XXXXXXXXXX` / `+91 XXXXX XXXXX`) and the email address (`hello@triptothai.com`) are placeholders carried over from the original brand brief. Replace them with the real contact details before launch — they appear in `Header.tsx`, `Footer.tsx`, and `contact.tsx`.

## Development Commands

```bash
npm run dev      # Start dev server
npm run build    # Production build
```
